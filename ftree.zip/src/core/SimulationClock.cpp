#include "core/SimulationClock.hpp"

namespace ftree::core {

void SimulationClock::nextYear() {
    currentYear_++;
}

} // namespace ftree::core
