#include "simulation/BirthSystem.hpp"
#include "core/RandomEngine.hpp"

namespace ftree::simulation {

int BirthSystem::processBirths(World& world) {
    int births = 0;
    auto living = world.getLivingPeople();
    
    for (PersonId id : living) {
        auto& person = world.getPersonRef(id);
        if (person.pregnant) {
            // Give birth - create child and add to family
            // Determine child gender randomly
            bool childIsMale = RandomEngine::getInstance().randomBool();
            Gender childGender = childIsMale ? ftree::domain::Gender::Male : ftree::domain::Gender::Female;
            PersonId childId = world.createPerson("Newborn", childGender, 0);
            
            if (person.familyId > 0) {
                auto& family = world.getFamilyRef(person.familyId);
                family.addChild(childId);
            }
            
            // Reset pregnancy
            person.pregnant = false;
            births++;
        }
    }
    
    return births;
}

PersonId BirthSystem::giveBirth(World& world, PersonId motherId, const std::string& surname) {
    return 0;
}

void BirthSystem::resetPregnancy(World& world, PersonId motherId) {
    auto& mother = world.getPersonRef(motherId);
    mother.pregnant = false;
}
