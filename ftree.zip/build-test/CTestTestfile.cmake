# CMake generated Testfile for 
# Source directory: /home/evilfox/ftree
# Build directory: /home/evilfox/ftree/build-test
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
include("/home/evilfox/ftree/build-test/FamilyTreeTests[1]_include.cmake")
